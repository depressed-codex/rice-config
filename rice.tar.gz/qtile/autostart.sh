fcitx5 -d &

nitrogen --restore &

picom &
